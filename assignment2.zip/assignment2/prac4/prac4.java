package com.example.prac4;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapplication.R;

public class prac4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prac4);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Context c = this;
        TextView tx1 = findViewById(R.id.tx1);
        TextView tx2 = findViewById(R.id.tx2);
        Button b1 = findViewById(R.id.b1);
    }
        public void btn(View v)
        {
            TextView tx1 = findViewById(R.id.tx1);
            TextView tx2 = findViewById(R.id.tx2);
            Context c = this;
            String s1,s2;
            s1=tx1.getText().toString();
            s2=tx2.getText().toString();
            Intent intent = new Intent(c, prac4b.class);
            intent.putExtra("tx1",s1+s2);
            startActivity(intent);

        }
}
