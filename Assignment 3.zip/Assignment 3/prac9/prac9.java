package com.example.prac9;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.example.myapplication.R;

public class prac9 extends AppCompatActivity {
    CheckBox cb1,cb2,cb3;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prac9);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        cb1=findViewById(R.id.cb1);
        cb2=findViewById(R.id.cb2);
        cb3=findViewById(R.id.cb3);
        b1=findViewById(R.id.bt1);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
        public void msg(View view)
        {
            if(cb1.isChecked() && cb2.isChecked() &&cb3.isChecked())
            {
                Toast.makeText(this, "Your hobby is cricket,tenis And badminton", Toast.LENGTH_SHORT).show();
            }
            else if(cb1.isChecked() && cb2.isChecked())
            {
                Toast.makeText(this, "Your hobby is cricket and tenis", Toast.LENGTH_SHORT).show();
            }
            else if(cb2.isChecked() && cb3.isChecked())
            {
                Toast.makeText(this, "Your hobby is tenis and badminton", Toast.LENGTH_SHORT).show();
            }
            else if(cb1.isChecked() && cb3.isChecked())
            {
                Toast.makeText(this, "Your hobby is Cricket and badminton", Toast.LENGTH_SHORT).show();
            } 
            else if(cb3.isChecked())
            {
                Toast.makeText(this, "Your hobby is badminton", Toast.LENGTH_SHORT).show();
            }
            else if(cb2.isChecked())
            {
                Toast.makeText(this, "Your hobby is Tenis.", Toast.LENGTH_SHORT).show();
            }
            else if(cb1.isChecked())
            {
                Toast.makeText(this, "Your hobby is Cricket", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this, "check the chekbox!!", Toast.LENGTH_SHORT).show();  
            }
        }

}
