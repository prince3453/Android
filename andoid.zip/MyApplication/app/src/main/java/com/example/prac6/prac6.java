package com.example.prac6;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class prac6 extends AppCompatActivity {
    EditText et1,et2;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prac6);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        et1=(EditText)findViewById(R.id.i1);
        et2=(EditText)findViewById(R.id.i2);
        b1=(Button)findViewById(R.id.b1);

        b1.setEnabled(false);
        et2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                                                 @Override
                                                 public void onFocusChange(View view, boolean b) {
                                                    String s1,s2;
                                                    s1=et1.getText().toString();
                                                    s2=et2.getText().toString();
                                                    if(s1.equals("prince") && s2.equals("prince"))
                                                    {
                                                        b1.setEnabled(true);
                                                    }
                                                    else{
                                                        b1.setEnabled(false);
                                                    }
                                                 }
                                             });
    }

}
