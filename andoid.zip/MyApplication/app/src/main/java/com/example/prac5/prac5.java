package com.example.prac5;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.R;

public class prac5 extends AppCompatActivity {
    EditText et1,et2;
    Context c =this;
    String str,str1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prac5);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }
    public void msg1(View v)
    {
              et1=findViewById(R.id.i1);
              et2=findViewById(R.id.i2);
              String s1 = "scet";
              if(et1.getText().toString().equals(s1) && et2.getText().toString().equals(s1))
              {
                  Intent intent = new Intent(this,prac5b.class);
                  intent.putExtra("message","welcome " + et1.getText().toString());
                  startActivity(intent);

        }else
        {
            Toast.makeText(this, "Enter valid LOGIN!!!!!", Toast.LENGTH_LONG).show();
        }
    }

}
