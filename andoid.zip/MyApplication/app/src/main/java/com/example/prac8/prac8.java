package com.example.prac8;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.myapplication.R;

public class prac8 extends AppCompatActivity {
    ToggleButton tb1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prac8);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tb1=findViewById(R.id.tb1);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    public void msg(View view)
    {
        if(tb1.isChecked())
        {
            Toast.makeText(this, "Toggle button is on!!!!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "Toggle button is OFF!!!!", Toast.LENGTH_SHORT).show();
        }
    }
}
